// Constructor
// section selecter var
const sizeSelector = document.getElementById("shed-size-selector")
const partitionSelector = document.getElementById("shed-paint-selector")

// positioning elements
var positiningShedImg1 = document.getElementById("positioning-shed-img-1")
var positiningDoorImg1 = document.getElementById("positioning-door-img-1")
var positiningShedImg2 = document.getElementById("positioning-shed-img-2")
var positiningDoorImg2 = document.getElementById("positioning-door-img-2")

var positiningDoorImg3 = document.getElementById("positioning-door-img-3")

//positioning Variable
var doorLeft1 = 0
var doorLeftLimit1 = 0
var doorRightLimit1 = 0

var doorLeft2 = 0
var doorLeftLimit2 = 0
var doorRightLimit2 = 0

var currentWindowCounter = 1
var currentWindowSide = ""

var windowRightLimit = 0

var windowLeft = 0
var windowLeftLimit = 0

// display moduals
const partitionModel = document.getElementById("partition-dropdown")
const pentDownPipeModel = document.getElementById("downpipe-pent")
const apexDownPipeModel = document.getElementById("downpipe-apex")
const partitionBtnSection = document.getElementById("partition-btns-section")


// selection display var
const curreySymbol = "£ "
const baseShedSizeTxt = document.getElementById("shed-size-txt")
const doorNumberTxt = document.getElementById("door-number-txt")
const windowNumberTxt = document.getElementById("window-number-txt")
const weatherboardPriceTxt = document.getElementById("price-weatherdoard")
const shiplapPriceTxt = document.getElementById("price-shiplap")
const logLapTxt = document.getElementById("price-loglap")
const dindowNumberTxt = document.getElementById("window-displayTxt")
const windowSelectionTxt = document.getElementById("window-lable")
const heavyFletTxt = document.getElementById("heavy-felt-lb")
const membranePriceTxt = document.getElementById("membrane-lining-price-txt")
const paintPriceTxt = document.getElementById("paint-price-lb")
const colorDisplay = document.getElementById("color-display")
const pavingSlabTxt = document.getElementById("paving-slab-price-txt")
const extraHightLb = document.getElementById("extra-height-lable")

// cost display
// cost display variables
const basePriceDisp = document.getElementById("base-price")
const doorPriceDisp = document.getElementById("door-price")
const windowPriceDisp = document.getElementById("window-price")
const feltPriceDisp = document.getElementById("felt-price")
const membranePriceDisp = document.getElementById("membrane-price")
const paintPriceDisp = document.getElementById("paint-price")
const partitionPriceDisp = document.getElementById("partition-price")
const gutterPriceDisp = document.getElementById("gutter-price")
const pavingPriceDisp = document.getElementById("paving-slab-price")
const levelingPriceDisp = document.getElementById("leveling-frame-price")
const extrasPriceDisp = document.getElementById("optional-extras-price")
const extraHeightPrice = document.getElementById("extra-height-price")
const totalPriceDisp = document.getElementById("total-price")



const shedData = {
    "roofStyle": "",
    "size": "4' x 4'",
    "cladding": "",
    "doors": {
    },
    "numberWindows": "",
    "windows": {
    },
    "extras": {
    }
}

const pricingMatrix = {
    "4' x 4'":{"Weatherboard":540,"Shiplap":570,"Loglap":655.5,"No.of windows standard":1,"No. of doors standard":1,"Paving Slab base price":150,"Leveling frame":60,"HD Felt cost @£1.75":28,"Mem.lining cost":52,"Guttering Pent":28,"Guttering Apex Single":28,"Guttering Apex Double":56,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":230},
"5' x 4'":{"Weatherboard":600,"Shiplap":630,"Loglap":724.5,"No.of windows standard":1,"No. of doors standard":1,"Paving Slab base price":150,"Leveling frame":60,"HD Felt cost @£1.75":35,"Mem.lining cost":58.5,"Guttering Pent":35,"Guttering Apex Single":35,"Guttering Apex Double":70,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":250},
"5' x 5'":{"Weatherboard":660,"Shiplap":700,"Loglap":805,"No.of windows standard":1,"No. of doors standard":1,"Paving Slab base price":150,"Leveling frame":60,"HD Felt cost @£1.75":43.75,"Mem.lining cost":65,"Guttering Pent":35,"Guttering Apex Single":35,"Guttering Apex Double":70,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":270},
"6' x 4'":{"Weatherboard":650,"Shiplap":700,"Loglap":805,"No.of windows standard":1,"No. of doors standard":1,"Paving Slab base price":150,"Leveling frame":60,"HD Felt cost @£1.75":42,"Mem.lining cost":65,"Guttering Pent":42,"Guttering Apex Single":42,"Guttering Apex Double":84,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":270},
"6' x 5'":{"Weatherboard":720,"Shiplap":770,"Loglap":885.5,"No.of windows standard":1,"No. of doors standard":1,"Paving Slab base price":150,"Leveling frame":63,"HD Felt cost @£1.75":52.5,"Mem.lining cost":71.5,"Guttering Pent":42,"Guttering Apex Single":42,"Guttering Apex Double":84,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":290},
"6' x 6'":{"Weatherboard":790,"Shiplap":840,"Loglap":966,"No.of windows standard":1,"No. of doors standard":1,"Paving Slab base price":150,"Leveling frame":75.6,"HD Felt cost @£1.75":63,"Mem.lining cost":78,"Guttering Pent":42,"Guttering Apex Single":42,"Guttering Apex Double":84,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":310},
"7' x 4'":{"Weatherboard":710,"Shiplap":760,"Loglap":874,"No.of windows standard":1,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":58.8,"HD Felt cost @£1.75":49,"Mem.lining cost":71.5,"Guttering Pent":49,"Guttering Apex Single":49,"Guttering Apex Double":98,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":290},
"7' x 5'":{"Weatherboard":790,"Shiplap":840,"Loglap":966,"No.of windows standard":1,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":73.5,"HD Felt cost @£1.75":61.25,"Mem.lining cost":78,"Guttering Pent":49,"Guttering Apex Single":49,"Guttering Apex Double":98,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":310},
"7' x 6'":{"Weatherboard":860,"Shiplap":920,"Loglap":1058,"No.of windows standard":1,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":88.2,"HD Felt cost @£1.75":73.5,"Mem.lining cost":84.5,"Guttering Pent":49,"Guttering Apex Single":49,"Guttering Apex Double":98,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":330},
"7' x 7'":{"Weatherboard":940,"Shiplap":1000,"Loglap":1150,"No.of windows standard":1,"No. of doors standard":1,"Paving Slab base price":331,"Leveling frame":102.9,"HD Felt cost @£1.75":85.75,"Mem.lining cost":91,"Guttering Pent":49,"Guttering Apex Single":49,"Guttering Apex Double":98,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":350},
"8' x 4'":{"Weatherboard":770,"Shiplap":820,"Loglap":943,"No.of windows standard":2,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":67.2,"HD Felt cost @£1.75":56,"Mem.lining cost":78,"Guttering Pent":56,"Guttering Apex Single":56,"Guttering Apex Double":112,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":310},
"8' x 5'":{"Weatherboard":850,"Shiplap":910,"Loglap":1046.5,"No.of windows standard":2,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":84,"HD Felt cost @£1.75":70,"Mem.lining cost":84.5,"Guttering Pent":56,"Guttering Apex Single":56,"Guttering Apex Double":112,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":330},
"8' x 6'":{"Weatherboard":930,"Shiplap":990,"Loglap":1138.5,"No.of windows standard":2,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":100.8,"HD Felt cost @£1.75":84,"Mem.lining cost":91,"Guttering Pent":56,"Guttering Apex Single":56,"Guttering Apex Double":112,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":350},
"8' x 7'":{"Weatherboard":1020,"Shiplap":1080,"Loglap":1242,"No.of windows standard":2,"No. of doors standard":1,"Paving Slab base price":331,"Leveling frame":117.6,"HD Felt cost @£1.75":98,"Mem.lining cost":97.5,"Guttering Pent":56,"Guttering Apex Single":56,"Guttering Apex Double":112,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":370},
"8' x 8'":{"Weatherboard":1100,"Shiplap":1160,"Loglap":1334,"No.of windows standard":2,"No. of doors standard":1,"Paving Slab base price":331,"Leveling frame":134.4,"HD Felt cost @£1.75":112,"Mem.lining cost":104,"Guttering Pent":56,"Guttering Apex Single":56,"Guttering Apex Double":112,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":390},
"9' x 4'":{"Weatherboard":830,"Shiplap":890,"Loglap":1023.5,"No.of windows standard":2,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":75.6,"HD Felt cost @£1.75":63,"Mem.lining cost":84.5,"Guttering Pent":63,"Guttering Apex Single":63,"Guttering Apex Double":126,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":330},
"9' x 5'":{"Weatherboard":920,"Shiplap":980,"Loglap":1127,"No.of windows standard":2,"No. of doors standard":1,"Paving Slab base price":331,"Leveling frame":94.5,"HD Felt cost @£1.75":78.75,"Mem.lining cost":91,"Guttering Pent":63,"Guttering Apex Single":63,"Guttering Apex Double":126,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":350},
"9' x 6'":{"Weatherboard":1010,"Shiplap":1070,"Loglap":1230.5,"No.of windows standard":2,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":113.4,"HD Felt cost @£1.75":94.5,"Mem.lining cost":97.5,"Guttering Pent":63,"Guttering Apex Single":63,"Guttering Apex Double":126,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":370},
"9' x 7'":{"Weatherboard":1090,"Shiplap":1160,"Loglap":1334,"No.of windows standard":2,"No. of doors standard":1,"Paving Slab base price":331,"Leveling frame":132.3,"HD Felt cost @£1.75":110.25,"Mem.lining cost":104,"Guttering Pent":63,"Guttering Apex Single":63,"Guttering Apex Double":126,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":390},
"9' x 8'":{"Weatherboard":1180,"Shiplap":1250,"Loglap":1437.5,"No.of windows standard":2,"No. of doors standard":1,"Paving Slab base price":331,"Leveling frame":151.2,"HD Felt cost @£1.75":126,"Mem.lining cost":110.5,"Guttering Pent":63,"Guttering Apex Single":63,"Guttering Apex Double":126,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":410},
"10' x 4'":{"Weatherboard":890,"Shiplap":950,"Loglap":1092.5,"No.of windows standard":3,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":84,"HD Felt cost @£1.75":70,"Mem.lining cost":91,"Guttering Pent":70,"Guttering Apex Single":70,"Guttering Apex Double":140,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":350},
"10' x 5'":{"Weatherboard":980,"Shiplap":1040,"Loglap":1196,"No.of windows standard":3,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":105,"HD Felt cost @£1.75":87.5,"Mem.lining cost":97.5,"Guttering Pent":70,"Guttering Apex Single":70,"Guttering Apex Double":140,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":370},
"10' x 6'":{"Weatherboard":1080,"Shiplap":1140,"Loglap":1311,"No.of windows standard":3,"No. of doors standard":1,"Paving Slab base price":223,"Leveling frame":126,"HD Felt cost @£1.75":105,"Mem.lining cost":104,"Guttering Pent":70,"Guttering Apex Single":70,"Guttering Apex Double":140,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":390},
"10' x 7'":{"Weatherboard":1170,"Shiplap":1240,"Loglap":1426,"No.of windows standard":3,"No. of doors standard":1,"Paving Slab base price":331,"Leveling frame":147,"HD Felt cost @£1.75":122.5,"Mem.lining cost":110.5,"Guttering Pent":70,"Guttering Apex Single":70,"Guttering Apex Double":140,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":410},
"10' x 8'":{"Weatherboard":1260,"Shiplap":1340,"Loglap":1541,"No.of windows standard":3,"No. of doors standard":1,"Paving Slab base price":331,"Leveling frame":168,"HD Felt cost @£1.75":140,"Mem.lining cost":117,"Guttering Pent":70,"Guttering Apex Single":70,"Guttering Apex Double":140,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":430},
"11' x 4'":{"Weatherboard":950,"Shiplap":1010,"Loglap":1161.5,"No.of windows standard":3,"No. of doors standard":1,"Paving Slab base price":301,"Leveling frame":92.4,"HD Felt cost @£1.75":77,"Mem.lining cost":97.5,"Guttering Pent":77,"Guttering Apex Single":77,"Guttering Apex Double":154,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":370},
"11' x 5'":{"Weatherboard":1050,"Shiplap":1110,"Loglap":1276.5,"No.of windows standard":3,"No. of doors standard":1,"Paving Slab base price":301,"Leveling frame":115.5,"HD Felt cost @£1.75":96.25,"Mem.lining cost":104,"Guttering Pent":77,"Guttering Apex Single":77,"Guttering Apex Double":154,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":390},
"11' x 6'":{"Weatherboard":1150,"Shiplap":1220,"Loglap":1403,"No.of windows standard":3,"No. of doors standard":1,"Paving Slab base price":301,"Leveling frame":138.6,"HD Felt cost @£1.75":115.5,"Mem.lining cost":110.5,"Guttering Pent":77,"Guttering Apex Single":77,"Guttering Apex Double":154,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":410},
"11' x 7'":{"Weatherboard":1240,"Shiplap":1320,"Loglap":1518,"No.of windows standard":3,"No. of doors standard":1,"Paving Slab base price":444,"Leveling frame":161.7,"HD Felt cost @£1.75":134.75,"Mem.lining cost":117,"Guttering Pent":77,"Guttering Apex Single":77,"Guttering Apex Double":154,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":430},
"11' x 8'":{"Weatherboard":1340,"Shiplap":1420,"Loglap":1633,"No.of windows standard":3,"No. of doors standard":1,"Paving Slab base price":301,"Leveling frame":184.8,"HD Felt cost @£1.75":154,"Mem.lining cost":123.5,"Guttering Pent":77,"Guttering Apex Single":77,"Guttering Apex Double":154,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":450},
"12' x 4'":{"Weatherboard":1010,"Shiplap":1080,"Loglap":1242,"No.of windows standard":4,"No. of doors standard":1,"Paving Slab base price":301,"Leveling frame":100.8,"HD Felt cost @£1.75":84,"Mem.lining cost":104,"Guttering Pent":84,"Guttering Apex Single":84,"Guttering Apex Double":168,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":390},
"12' x 5'":{"Weatherboard":1110,"Shiplap":1180,"Loglap":1357,"No.of windows standard":4,"No. of doors standard":1,"Paving Slab base price":301,"Leveling frame":126,"HD Felt cost @£1.75":105,"Mem.lining cost":110.5,"Guttering Pent":84,"Guttering Apex Single":84,"Guttering Apex Double":168,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":410},
"12' x 6'":{"Weatherboard":1220,"Shiplap":1290,"Loglap":1483.5,"No.of windows standard":4,"No. of doors standard":1,"Paving Slab base price":301,"Leveling frame":151.2,"HD Felt cost @£1.75":126,"Mem.lining cost":117,"Guttering Pent":84,"Guttering Apex Single":84,"Guttering Apex Double":168,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":430},
"12' x 7'":{"Weatherboard":1320,"Shiplap":1400,"Loglap":1610,"No.of windows standard":4,"No. of doors standard":1,"Paving Slab base price":444,"Leveling frame":176.4,"HD Felt cost @£1.75":147,"Mem.lining cost":123.5,"Guttering Pent":84,"Guttering Apex Single":84,"Guttering Apex Double":168,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":450},
"12' x 8'":{"Weatherboard":1420,"Shiplap":1510,"Loglap":1736.5,"No.of windows standard":4,"No. of doors standard":1,"Paving Slab base price":444,"Leveling frame":201.6,"HD Felt cost @£1.75":168,"Mem.lining cost":130,"Guttering Pent":84,"Guttering Apex Single":84,"Guttering Apex Double":168,"Downpipe Pent":35,"Downpipe single gutter apex":35,"Downpipe double gutter apex":70,"Paint":470}
}


function changeModelBtn(element) {
    // handel the nav changes
    var allModels = document.getElementsByClassName("nav-link")    
    for (var i = 0; i < allModels.length; i ++) {
        if (allModels[i].className == "nav-link active") {
            
            if (element.getAttribute("data-direction") == "next") {              
                if (i < allModels.length - 1) {
                    allModels[i].className = "nav-link"
                    allModels[i + 1].className = "nav-link active"
                    document.getElementById(allModels[i].getAttribute("data-model")).style.display = "none"
                    document.getElementById(allModels[i + 1].getAttribute("data-model")).style.display = "block"
                }                 
            } else {
                if (i > 0) {
                    allModels[i].className = "nav-link"
                    allModels[i - 1].className = "nav-link active"

                    document.getElementById(allModels[i].getAttribute("data-model")).style.display = "none"
                    document.getElementById(allModels[i - 1].getAttribute("data-model")).style.display = "block"
                }                
            }
            break
        } 
    }
    document.getElementById("main-progress-btn").display = "flex"
}

function updatePricing() {
    console.log(shedData)
    var totalCost = 0
    var doorCost = 0
    var numberOfWindows = Object.keys(shedData["windows"]).length
    var windowsCost = 0
    var extrasCost = 0
    
    // base price
    if (!shedData.cladding == "" && !shedData.size == "" && !shedData.roofStyle == "") {
        totalCost += pricingMatrix[shedData.size][shedData.cladding]
        basePriceDisp.innerText = curreySymbol + pricingMatrix[shedData.size][shedData.cladding]
    }


    switch (shedData["door-1"]) {
        case "210":
            totalCost += 25
            doorCost += 25
            break
        case "stable":
            totalCost += 50
            doorCost += 50
            break
        case "double":
            totalCost += 75
            doorCost += 75
            break
        case "2-single":
            totalCost += 100
            doorCost += 100
            break
    }

    switch (shedData["door-2"]) {
        case "210":
            totalCost += 25
            doorCost += 25
            break
        case "stable":
            totalCost += 50
            doorCost += 50
            break
        case "double":
            totalCost += 75
            doorCost += 75
            break
        case "2-single":
            totalCost += 100
            doorCost += 100
            break
    }

    if (numberOfWindows > 0) {
        for (let i = 1; i <= numberOfWindows; i ++) {
            switch (shedData["windows"]["window-" + i]["type"]) {
                case "toughened":
                    windowsCost += 25
                    totalCost += 25
                    break
                case "opening":
                    windowsCost += 55
                    totalCost += 55
                    break

            }
        }

        if (numberOfWindows > pricingMatrix[shedData["size"]]["No.of windows standard"]) {
            windowsCost += (numberOfWindows - pricingMatrix[shedData["size"]]["No.of windows standard"]) * 25
            totalCost += (numberOfWindows - pricingMatrix[shedData["size"]]["No.of windows standard"]) * 25
        }
    }
    if (shedData["rooffelt"] == "heavy") {
        feltPriceDisp.innerText = curreySymbol + Number(pricingMatrix[shedData["size"]]["HD Felt cost @£1.75"])
        totalCost += Number(pricingMatrix[shedData["size"]]["HD Felt cost @£1.75"])
    }
    if (shedData["membrane"] == "yes") {
        membranePriceDisp.innerText = curreySymbol + Number(pricingMatrix[shedData["size"]]["Mem.lining cost"])
        totalCost += Number(pricingMatrix[shedData["size"]]["Mem.lining cost"])
    }
    if ("paint" in shedData) {
        paintPriceDisp.innerText = curreySymbol + Number(pricingMatrix[shedData["size"]]["Paint"])
        totalCost += Number(pricingMatrix[shedData["size"]]["Paint"])
    }
    if ("partition" in shedData) {
        partitionPriceDisp.innerText = curreySymbol + (Number(shedData["partition"]) * 25)
        totalCost += (Number(shedData["partition"]) * 25)
    }

    if ("gutter" in shedData) {
        switch (shedData["gutter"]) {
            case "single-pent":
                gutterPriceDisp.innerText = curreySymbol + Number(pricingMatrix[shedData["size"]]["Guttering Pent"])
                totalCost += Number(pricingMatrix[shedData["size"]]["Guttering Pent"])
                break
            case "single-apex":
                gutterPriceDisp.innerText = curreySymbol + Number(pricingMatrix[shedData["size"]]["Guttering Apex Single"])
                totalCost += Number(pricingMatrix[shedData["size"]]["Guttering Apex Single"])
                break
            case "double":
                gutterPriceDisp.innerText = curreySymbol + Number(pricingMatrix[shedData["size"]]["Guttering Apex Double"])
                totalCost += Number(pricingMatrix[shedData["size"]]["Guttering Apex Double"])
                break
        }
    }
    if ("paving" in shedData) {
        pavingPriceDisp.innerText = Number(pricingMatrix[shedData["size"]]["Paving Slab base price"])
        totalCost += Number(pricingMatrix[shedData["size"]]["Paving Slab base price"])
    }
    if ("levellingframe" in shedData) {
        levelingPriceDisp.innerText = Number(pricingMatrix[shedData["size"]]["Leveling frame"])
        totalCost += Number(pricingMatrix[shedData["size"]]["Leveling frame"])
    }
    for (key in shedData["extras"]) {
        extrasCost += Number(shedData["extras"][key])
    }

    extraHightLb.innerText = "Add Extra Height + " + curreySymbol + (pricingMatrix[shedData["size"]][shedData["cladding"]] * 0.1).toFixed(2)

    if (shedData["extra-height"] == "yes") {
        extraHeightPrice.innerText = curreySymbol + Number((pricingMatrix[shedData.size][shedData.cladding] * 0.1).toFixed(2))
        totalCost += Number((pricingMatrix[shedData.size][shedData.cladding] * 0.1).toFixed(2))
    } else {
        extraHeightPrice.innerText = curreySymbol + 0
    }


    doorPriceDisp.innerText = curreySymbol + doorCost
    windowPriceDisp.innerText = curreySymbol + windowsCost
    extrasPriceDisp.innerText = curreySymbol + extrasCost
    totalPriceDisp.innerText = curreySymbol + totalCost
    
}
function openAdditionalModel(element) {
    switch(element.getAttribute("data-model")) {
        case "door-upgrade-1":
            document.getElementById("door-upgrade-1").style.display = "block"
            break
        
        case "door-upgrade-2":
            document.getElementById("door-upgrade-2").style.display = "block"
            break

    } 
    document.getElementById("upggrade-btns").style.display = "none"
    document.getElementById("main-progress-btn").style.display = "none"      
}



function savePrice(element) {

    shedData[element.getAttribute("data-key")] = element.getAttribute("data-value")
    updatePricing()
    
}
function savePriceCheckBox(element) {
    if(element.checked) {
        shedData["extras"][element.getAttribute("data-key")] = element.getAttribute("data-price")
    } else {
        delete shedData["extras"][element.getAttribute("data-key")]
    }
    updatePricing()
    
    
}
function saveShedSize () {
    shedData["size"] = sizeSelector.value
    weatherboardPriceTxt.innerText = "£ " + pricingMatrix[shedData["size"]]["Weatherboard"]
    shiplapPriceTxt.innerText = "£ " + pricingMatrix[shedData["size"]]["Shiplap"]
    logLapTxt.innerText = "£ " + pricingMatrix[shedData["size"]]["Loglap"]
    dindowNumberTxt.innerText = "The shed size you have chosen includes " + pricingMatrix[shedData["size"]]["No.of windows standard"] + " windows as standard. Do you want to add more"
    heavyFletTxt.innerText = "£ " + pricingMatrix[shedData["size"]]["HD Felt cost @£1.75"]
    membranePriceTxt.innerText = "£ " + pricingMatrix[shedData["size"]]["Mem.lining cost"]
    paintPriceTxt.innerText = "£ " + pricingMatrix[shedData["size"]]["Paint"]
    pavingSlabTxt.innerText = "£ " + pricingMatrix[shedData["size"]]["Paving Slab base price"]
    

    // display gutterdata
    if (shedData["roofStyle"] == "pent") {
        pentDownPipeModel.style.display = "block"
        apexDownPipeModel.style.display = "none"
        document.getElementById("gutter-pent-single").innerText = "Add guttering & downpipes + £" + pricingMatrix[shedData["size"]]["Guttering Pent"]
    } else if (shedData["roofStyle"] == "apex") {
        apexDownPipeModel.style.display = "block"
        pentDownPipeModel.style.display = "none"
        document.getElementById("gutter-apex-single").innerText = "Add single-sided guttering & downpipes + £" + pricingMatrix[shedData["size"]]["Guttering Apex Single"]
        document.getElementById("gutter-apex-double").innerText = "Add double-sided guttering & downpipes + £" + pricingMatrix[shedData["size"]]["Guttering Apex Double"]
    }
}
function clearActiveNav(element) {   
    // get all nav elements loop thru and set to inactive
    var navItems = document.getElementsByClassName("nav-item") 
    for (var i = navItems.length -1; i >=0; i --) {
        navItems[i].children[0].className = "nav-link"
    }

    // hide all construction models
    var constructionModels = document.getElementsByClassName("design-models")
    for (var i = constructionModels.length -1; i >=0; i --) {
        constructionModels[i].style.display = "none"
    }

    // set clicked element to active
    element.className = "nav-link active"
    
    var unhiddenModel = document.getElementById(element.getAttribute("data-model"))
    unhiddenModel.style.display = "block"
    document.getElementById("main-progress-btn").style.display = "flex"
    
    
}
function openDoorPositioning(element) {
    

    if(element.getAttribute("data-key") == "door-1") {
        if (element.getAttribute("data-img") == "a") {
            positiningShedImg1.src = "/Images/FrontPanels/8 foot.png"           
        }
        else {
            positiningShedImg1.src = "Images/SidePanels/12 foot.png"
        }
        // display hidden elements
        positiningShedImg1.style.display = "block"
        positiningDoorImg1.style.display = "block"
        var shedRect = positiningShedImg1.getBoundingClientRect();
        doorTopVal = positiningShedImg1.height - positiningDoorImg1.height + shedRect.top + document.documentElement.scrollTop + "px"
        positiningDoorImg1.style.top = doorTopVal
        doorLeft1 = shedRect.left + 50
        doorLeftLimit1 = doorLeft1
        doorRightLimit1 = shedRect.right - 90 - positiningDoorImg1.clientWidth
        positiningDoorImg1.style.left = doorLeft1.toString() + "px"
        document.getElementById("door-movement-btns-1").style.display = "flex"

        shedData["doors"]["door-1"] = {
            "shedSide": element.getAttribute("data-possition"),
            "left": doorLeft1
        }

        

    } else {
        if (element.getAttribute("data-img") == "a") {
            positiningShedImg2.src = "/Images/FrontPanels/8 foot.png"
        }
        else {
            positiningShedImg2.src = "Images/SidePanels/12 foot.png"
        }
        // display hidden elements
        positiningShedImg2.style.display = "block"
        positiningDoorImg2.style.display = "block"
        var shedRect = positiningShedImg2.getBoundingClientRect();
        doorTopVal = positiningShedImg2.height - positiningDoorImg2.height + shedRect.top + document.documentElement.scrollTop + "px"
        
        doorLeft2 = shedRect.left + 50
        doorLeftLimit2 = doorLeft2
        doorRightLimit2 = shedRect.right - 90 - positiningDoorImg2.clientWidth
        
        document.getElementById("door-movement-btns-2").style.display = "flex"

        if (shedData["doors"]["door-1"]["shedSide"] == element.getAttribute("data-possition")) {
            doorLeftLimit2 = doorLeft1 + 200
            positiningDoorImg3.style.top = doorTopVal
            positiningDoorImg3.style.left = doorLeft1 + "px"
            positiningDoorImg3.style.display = "block"
            doorLeft2 = doorLeftLimit2            
        } else {
            positiningDoorImg3.style.display = "none"
        }

        positiningDoorImg2.style.top = doorTopVal
        positiningDoorImg2.style.left = doorLeft2.toString() + "px"

        shedData["doors"]["door-2"] = {
            "shedSide": element.getAttribute("data-possition"),
            "left": doorLeft2
        }
        
    }

    document.getElementById("main-progress-btn").style.display = "flex"
     
}

function moveDoor(element) {
    
    if (element.getAttribute("data-type") == "door-1") {
        if (element.getAttribute("data-direction") == "left" && doorLeft1 > doorLeftLimit1) {
            doorLeft1 -= 50
        } else if (element.getAttribute("data-direction") == "right" && doorLeft1 < doorRightLimit1) {
            doorLeft1 += 50
            
        }
        shedData["doors"]["door-1"]["left"] = doorLeft1
        positiningDoorImg1.style.left = doorLeft1.toString() + "px"
    } else {
        if (element.getAttribute("data-direction") == "left" && doorLeft2 > doorLeftLimit2) {
            doorLeft2 -= 50
        } else if (element.getAttribute("data-direction") == "right" && doorLeft2 < doorRightLimit2) {
            doorLeft2 += 50
        }
        positiningDoorImg2.style.left = doorLeft2.toString() + "px"
        shedData["doors"]["door-2"]["left"] = doorLeft2
    }
}

function addAditionalDoor() {

    if (document.getElementById("additionalDoor") == null) {
        var doorLink = document.getElementById("door-nav")

        //create elements
        var newDoorElement = document.createElement("li")
        var doorElementAnchor = document.createElement("a")

        //modify elements
        doorElementAnchor.innerText = "Additional Door"
        doorElementAnchor.className = "nav-link"
        doorElementAnchor.setAttribute("data-model", "door-select-model-2")
        doorElementAnchor.setAttribute("onclick", "clearActiveNav(this)")

        newDoorElement.className = "nav-item"
        newDoorElement.id = "additionalDoor"


        newDoorElement.appendChild(doorElementAnchor)

        doorLink.parentNode.insertBefore(newDoorElement, doorLink.nextSibling)
        clearActiveNav(doorElementAnchor)

    }
}
function windowsBtn(element) {
    switch(element.getAttribute("data-window")) {
        case "add":
            document.getElementById("primary-windows").style.display = "none"
            document.getElementById("additional-windows").style.display = "block"
            break
        
        case "standard":
            document.getElementById("primary-windows").style.display = "none"
            var element = document.createElement("input")
            element.setAttribute("data-window-number", "0")
            windowUpgrade(element)
            
            break
        
        case "none":
            var element = document.createElement("input")
            element.setAttribute("data-direction", "next")
            changeModelBtn(element)

            break
    } 
}

function windowUpgrade(element) {
    
    var upgradeSection = document.getElementById("window-upgrade")
    document.getElementById("additional-windows").style.display = "none"

    if (element.getAttribute("data-window-number") == "") {
        var numberOfWindows = pricingMatrix[shedData["size"]]["No.of windows standard"]
    }
    else {
        var numberOfWindows = Number(pricingMatrix[shedData["size"]]["No.of windows standard"]) + Number(element.getAttribute("data-window-number"))
    }
    
    // populate and add window options
    for (let i = 1; i <= numberOfWindows; i ++) {
        // save aditional windows
        shedData["windows"]["window-" + i] = {
            "type": "Standard"
        }

        // lable
        windowLable = document.createElement("h4")
        windowLable.innerText = "Window " + i + ":"
        windowLable.style.display = "inline"
        windowLable.style.marginRight = "50px"
        
        // standard
        radioBtnStd = document.createElement("input")
        radioBtnStd.type = "radio"
        radioBtnStd.id = "window-standard" + i
        radioBtnStd.name = "window-upgrade" + i
        radioBtnStd.setAttribute("data-window-number", i)
        radioBtnStd.setAttribute("data-window-type", "standard")
        radioBtnStd.setAttribute("onclick", "windowTypeUpdate(this)")
        radioBtnStd.checked = true

        radioBtnStdLable = document.createElement("label")
        radioBtnStdLable.setAttribute("for", "window-standard" + i)
        radioBtnStdLable.innerText = "Standard"
        radioBtnStdLable.style.marginRight = "50px"


        // Toughened
        radioBtnToughened = document.createElement("input")
        radioBtnToughened.type = "radio"
        radioBtnToughened.id = "window-toughened" + i
        radioBtnToughened.name = "window-upgrade" + i
        radioBtnToughened.setAttribute("data-window-number", i)
        radioBtnToughened.setAttribute("data-window-type", "toughened")
        radioBtnToughened.setAttribute("onclick", "windowTypeUpdate(this)")
        
        radioBtnToughenedLable = document.createElement("label")
        radioBtnToughenedLable.setAttribute("for", "window-toughened" + i)
        radioBtnToughenedLable.innerText = "toughened +£25"
        radioBtnToughenedLable.style.marginRight = "50px"

        //Convert to Opening 
        radioBtnOpening = document.createElement("input")

        radioBtnOpening.type = "radio"
        radioBtnOpening.id = "window-opening" + i
        radioBtnOpening.name = "window-upgrade" + i
        radioBtnOpening.setAttribute("data-window-number", i)
        radioBtnOpening.setAttribute("data-window-type", "opening")
        radioBtnOpening.setAttribute("onclick", "windowTypeUpdate(this)")
        
        radioBtnOpeningLable = document.createElement("label")
        radioBtnOpeningLable.setAttribute("for", "window-opening" + i)
        radioBtnOpeningLable.innerText = "Convert to Opening +£55"
        radioBtnOpeningLable.style.marginRight = "50px"


        // add elements to document
        lineBreak = document.createElement("br")
        upgradeSection.append(windowLable)

        upgradeSection.append(radioBtnStd)
        upgradeSection.append(radioBtnStdLable)

        upgradeSection.append(radioBtnToughened)
        upgradeSection.append(radioBtnToughenedLable)

        upgradeSection.append(radioBtnOpening)
        upgradeSection.append(radioBtnOpeningLable)

        upgradeSection.append(lineBreak)
        
    }
    updatePricing()

    document.getElementById("window-placement").style.display = "block"
}

function positionWindow(element) {
    document.getElementById("positioning-windows-shed-img").style.display = "block"
    document.getElementById("window-manipulation").style.display = "block"
    if (element.getAttribute("data-img") == "a") {
        document.getElementById("positioning-windows-shed-img").src = "/Images/FrontPanels/8 foot.png"           
    }
    else {
        document.getElementById("positioning-windows-shed-img").src = "Images/SidePanels/12 foot.png"
    }

    // counter for door number
    var doorCounter = 0
    windowPlacementShed = document.getElementById("positioning-windows-shed-img")
    document.getElementById("shed-window-" + currentWindowCounter).style.display = "block"  
    
    // save current window side
    currentWindowSide = element.getAttribute("data-possition")

    shedWindowRect = windowPlacementShed.getBoundingClientRect();  
    window1ImgTopVal = windowPlacementShed.height - document.getElementById("shed-window-" + currentWindowCounter).height + shedWindowRect.top + document.documentElement.scrollTop - 300 + "px"

    
    windowRightLimit = shedWindowRect.right - 40 - document.getElementById("shed-window-" + currentWindowCounter).clientWidth
    // populate doors
    for (const door in shedData["doors"]) {
        doorCounter += 1
        if(element.getAttribute("data-possition") == shedData["doors"][door]["shedSide"]) {
            //handel multiple doors
            
            windowPlacementDoor = document.getElementById("positioning-window-door-img-" + doorCounter)
            

            // posistion doors           
            doorTopValWindow = windowPlacementShed.height - windowPlacementDoor.height + shedWindowRect.top + document.documentElement.scrollTop + "px"
            windowPlacementDoor.style.display = "block"

            windowPlacementDoor.style.top = doorTopValWindow
            windowPlacementDoor.style.left = shedData["doors"][door]["left"] + "px"
            windowLeft = Number(shedData["doors"][door]["left"] + 200)

        } else {
            document.getElementById("positioning-window-door-img-" + doorCounter).style.display = "none"
            windowLeft = Number(shedWindowRect.left + 50)
        }
    }
    // populate windows
    for (i = 1; i < currentWindowCounter; i++) {
        console.log(i)
        if (element.getAttribute("data-possition") == shedData["windows"]["window-" + i]["side"]) {
            document.getElementById("shed-window-" + i).style.display = "block" 
            document.getElementById("shed-window-" + i).style.top = window1ImgTopVal
            document.getElementById("shed-window-" + i).style.left = shedData["windows"]["window-" + i]["left"] + "px"
        }
        else {
            document.getElementById("shed-window-" + i).style.display = "none" 

        }
    }


    windowLeftLimit = windowLeft
    document.getElementById("shed-window-" + currentWindowCounter).style.top = window1ImgTopVal
    document.getElementById("shed-window-" + currentWindowCounter).style.left = windowLeft  + "px"

    shedData["windows"]["window-" + currentWindowCounter]["left"] = windowLeft
    shedData["windows"]["window-" + currentWindowCounter]["side"] = currentWindowSide

    
        
}

function selectWindow(element) {  
    
    if (element.getAttribute("data-direction") == "next" && shedData["windows"].hasOwnProperty("window-" + Number(currentWindowCounter + 1))) {
        windowSelectionTxt.innerText = "Window " + Number(currentWindowCounter + 1)
        currentWindowCounter += 1

        document.getElementById("shed-window-" + currentWindowCounter).style.top = window1ImgTopVal
        document.getElementById("shed-window-" + currentWindowCounter).style.left = windowLeft  + "px"
        document.getElementById("shed-window-" + currentWindowCounter).style.display = "block"  


    } else if (element.getAttribute("data-direction") == "back" && currentWindowCounter > 1) {
        windowSelectionTxt.innerText = "Window " + Number(currentWindowCounter - 1)
        document.getElementById("shed-window-" + currentWindowCounter).style.display = "none" 
        currentWindowCounter -= 1

    }

}

function moveWindow(element) {

    if (element.getAttribute("data-direction") == "left" && windowLeft > windowLeftLimit) {
        windowLeft -= 50
    } else if (element.getAttribute("data-direction") == "right" && windowLeft < windowRightLimit) {
        windowLeft += 50
        
    }
    window1Img = document.getElementById("shed-window-" + currentWindowCounter)
    window1Img.style.left = windowLeft.toString() + "px"
    shedData["windows"]["window-" + currentWindowCounter]["left"] = windowLeft
    shedData["windows"]["window-" + currentWindowCounter]["side"] = currentWindowSide


    console.log(shedData)
    

}
function windowTypeUpdate(element) {
    shedData["windows"]["window-" + element.getAttribute("data-window-number")]["type"] = element.getAttribute("data-window-type")
    updatePricing()
}
function openPaint() {
    document.getElementById("color-selector").style.display = "block"
    
    
}

window.addEventListener('resize', function(event){
    console.log("win")
  });

function paintSelection(element) {
    colorDisplay.style.backgroundColor = element.getAttribute("data-color")  
    shedData["paint"] = element.getAttribute("data-color")  
    updatePricing()

}

function openPartition() {
    partitionBtnSection.style.display = "none"
    partitionModel.style.display = "block"
    shedData["partition"] = 1

}

function saveShedPartition() {
    shedData["partition"] = partitionSelector.value
    updatePricing()
    
}










