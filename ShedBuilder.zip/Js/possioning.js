//image variables

const shedDoor = document.getElementById('door1');

var doorMargin = (screen.width -  shedDoor.clientWidth) / 2
shedDoor.style.marginLeft = doorMargin + "px";




//move object
function moveObject(element) {
    if (element.getAttribute("data-direction") == "left") {
        return -50
    } else {
        return 50
    }
}



// select and move object
function objectHandeler(element) {
    if (element.getAttribute("data-type") == "door") {
        doorMargin += moveObject(element)
        shedDoor.style.marginLeft = doorMargin + "px";
    }
    
}

